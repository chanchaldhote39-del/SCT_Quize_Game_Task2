// Get DOM elements
const taskInput = document.getElementById("taskInput");
const taskDateTime = document.getElementById("taskDateTime");
const taskList = document.getElementById("taskList");
const addBtn = document.getElementById("addBtn");

// Add task on button click
addBtn.addEventListener("click", addTask);

function addTask() {
  const text = taskInput.value.trim();
  const time = taskDateTime.value;

  if (!text) {
    alert("Please enter a task!");
    return;
  }

  // Create list item
  const li = document.createElement("li");

  // Task info
  const info = document.createElement("div");
  
  const taskSpan = document.createElement("span");
  taskSpan.textContent = text;
  taskSpan.className = "task-text";

  const dateSpan = document.createElement("div");
  dateSpan.textContent = time ? "📅 " + new Date(time).toLocaleString() : "";
  dateSpan.className = "date-time";

  info.appendChild(taskSpan);
  info.appendChild(dateSpan);

  // Action buttons
  const actions = document.createElement("div");
  actions.className = "actions";

  const completeBtn = document.createElement("button");
  completeBtn.textContent = "✔";
  completeBtn.onclick = () => li.classList.toggle("completed");

  const editBtn = document.createElement("button");
  editBtn.textContent = "✏";
  editBtn.onclick = () => editTask(taskSpan, dateSpan);

  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "🗑";
  deleteBtn.onclick = () => li.remove();

  actions.appendChild(completeBtn);
  actions.appendChild(editBtn);
  actions.appendChild(deleteBtn);

  li.appendChild(info);
  li.appendChild(actions);
  taskList.appendChild(li);

  taskInput.value = "";
  taskDateTime.value = "";
}

function editTask(taskSpan, dateSpan) {
  const newText = prompt("Edit Task:", taskSpan.textContent);
  if (newText) taskSpan.textContent = newText;

  const newDate = prompt("Edit Date & Time (YYYY-MM-DD HH:MM):", "");
  if (newDate) dateSpan.textContent = "📅 " + new Date(newDate).toLocaleString();
}
